import "./globals.css";

export const metadata = {
  title: "Портфолио Ильи Абрамова",
  description: "",
};

export default function RootLayout({ children }) {
    return (
        <html lang="ru">
            <body className="appBody"> 
                { children }
            </body>
        </html>
    )
}
