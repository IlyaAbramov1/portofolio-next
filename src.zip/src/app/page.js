import HomePage from "@/components/home/HomePage";

export default function Page() {
    return <HomePage />
}