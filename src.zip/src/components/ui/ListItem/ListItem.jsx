import Reveal from "../Reveal/Reveal";
import styles from "./ListItem.module.css"

export default function ListItem({
    cover,
    title,
    description,
    isNew = false,
    linkText,
    href
}) {
    const Wrapper = href ? "a" : "div";

    return (
        <Reveal>
            <Wrapper href={href} className={styles.listItemContainer} target="_blank">
                {cover ? (
                    <img className={styles.listItemCover} src={cover} alt="" />
                ) : null}
                <div className={styles.listItemContent}>
                    <div className={styles.listItemText}>
                        <div className={styles.listItemTitle}>{title}</div>
                        <div className={styles.listItemDescription}>
                            {isNew ? 
                                <div className="hashtagNew">Новое</div>
                                : null
                            }
                            <div className={styles.listItemSubText}>{description}</div>
                        </div>
                    </div>
                    {linkText ? <span className={styles.linkButton}>{linkText}</span> : null}
                </div>
            </Wrapper>
        </Reveal>
    )
}
