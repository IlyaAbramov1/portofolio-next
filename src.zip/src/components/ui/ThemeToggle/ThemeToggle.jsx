 "use client";

import { useEffect, useState } from "react";
import styles from "./ThemeToggle.module.css";

export default function ThemeToggle() {
    const [isDark, setIsDark] = useState(false);

    useEffect(() => {
        if (typeof document === "undefined") return;
        setIsDark(document.body.classList.contains("dark-theme"));
    }, []);

    const handleToggle = () => {
        if (typeof document === "undefined") return;
        const nextIsDark = !document.body.classList.contains("dark-theme");
        document.body.classList.toggle("dark-theme", nextIsDark);
        setIsDark(nextIsDark);
    };

    return (
        <button
            type="button"
            className={styles.themeToggle}
            onClick={handleToggle}
            aria-pressed={isDark}
            aria-label="Переключить тему"
        >
            <img
                src={
                    isDark
                        ? "/default-icons/dark-theme/moon.svg"
                        : "/default-icons/light-theme/sun.svg"
                }
                alt=""
            />
        </button>
    )
}
