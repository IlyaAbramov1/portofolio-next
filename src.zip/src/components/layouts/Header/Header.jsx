import ThemeToggle from "@/components/ui/ThemeToggle/ThemeToggle"

import styles from "./Header.module.css";
import Reveal from "@/components/ui/Reveal/Reveal";

function LinksRow({ label, links }) {
    if (!label && (!links || links.length === 0)) return null;

    return (
        <Reveal>
            <div className={styles.row}>
                {label ? <span className="text">{label}</span> : null}
                {links && links.length > 0 ? (
                    <nav className={styles.links} aria-label={label || "Навигация"}>
                        {links.map((l) => (
                            <a
                                key={`${l.href}-${l.label}`}
                                className="link"
                                href={l.href}
                                target={l.external ? "_blank" : undefined}
                                rel={l.external ? "noreferrer" : undefined}
                            >
                                {l.label}
                            </a>
                        ))}
                    </nav>
                ) : null}
            </div>
        </Reveal>
    )
}

export default function Header({
    logo,
    primaryLabel,
    primaryLinks,
    secondaryLabel,
    secondaryLinks,
    bottomSlot
}) {
    return (
        <header className={styles.header}>
            <Reveal>
                <div className={styles.topRow}>
                    <div className={styles.logo}>{logo}</div>
                    <ThemeToggle />
                </div>
            </Reveal>

            <LinksRow label={primaryLabel} links={primaryLinks}/>
            <LinksRow label={secondaryLabel} links={secondaryLinks}/>

            <Reveal>
                {bottomSlot ? <div className={styles.bottom}>{bottomSlot}</div> : null}
            </Reveal>
        </header>
    )
}
